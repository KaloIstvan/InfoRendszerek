export class ManufacturingItem {
    id: number = 0;
    manufacturingName: string = '';
    quantity: number = 0;
  
  }